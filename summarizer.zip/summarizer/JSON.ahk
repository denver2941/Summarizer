; JSON.ahk - Simple JSON parser for AutoHotkey v1.1
; Usage: obj := JSON_Parse(jsonString)

global __json_str := "", __json_pos := 1

JSON_Parse(json) {
    global __json_str, __json_pos
    __json_str := Trim(json)
    __json_pos := 1
    return JSON_ParseValue()
}

JSON_ParseValue() {
    global __json_str, __json_pos
    JSON_SkipWhitespace()
    ch := SubStr(__json_str, __json_pos, 1)
    if (ch = "{")
        return JSON_ParseObject()
    else if (ch = "[")
        return JSON_ParseArray()
    else if (ch = """")
        return JSON_ParseString()
    else if (RegExMatch(SubStr(__json_str, __json_pos), "^(true|false|null)"))
        return JSON_ParseLiteral()
    else
        return JSON_ParseNumber()
}

JSON_SkipWhitespace() {
    global __json_str, __json_pos
    while (__json_pos <= StrLen(__json_str) && RegExMatch(SubStr(__json_str, __json_pos, 1), "^[ \t\r\n]"))
        __json_pos++
}

JSON_ParseObject() {
    global __json_str, __json_pos
    obj := {}
    __json_pos++  ; skip '{'
    JSON_SkipWhitespace()
    if (SubStr(__json_str, __json_pos, 1) = "}") {
        __json_pos++
        return obj
    }
    Loop {
        JSON_SkipWhitespace()
        key := JSON_ParseString()
        JSON_SkipWhitespace()
        if (SubStr(__json_str, __json_pos, 1) != ":") {
            MsgBox, 16, JSON Error, Expected ':' at position %__json_pos%
            ExitApp
        }
        __json_pos++ ; skip ':'
        JSON_SkipWhitespace()
        value := JSON_ParseValue()
        obj[key] := value
        JSON_SkipWhitespace()
        ch := SubStr(__json_str, __json_pos, 1)
        if (ch = "}") {
            __json_pos++
            break
        } else if (ch = ",") {
            __json_pos++
            continue
        } else {
            MsgBox, 16, JSON Error, Expected ',' or '}' at position %__json_pos%
            ExitApp
        }
    }
    return obj
}

JSON_ParseArray() {
    global __json_str, __json_pos
    arr := []
    __json_pos++ ; skip '['
    JSON_SkipWhitespace()
    if (SubStr(__json_str, __json_pos, 1) = "]") {
        __json_pos++
        return arr
    }
    Loop {
        JSON_SkipWhitespace()
        value := JSON_ParseValue()
        arr.Push(value)
        JSON_SkipWhitespace()
        ch := SubStr(__json_str, __json_pos, 1)
        if (ch = "]") {
            __json_pos++
            break
        } else if (ch = ",") {
            __json_pos++
            continue
        } else {
            MsgBox, 16, JSON Error, Expected ',' or ']' at position %__json_pos%
            ExitApp
        }
    }
    return arr
}

JSON_ParseString() {
    global __json_str, __json_pos
    result := ""
    __json_pos++ ; skip opening quote
    Loop {
        if (__json_pos > StrLen(__json_str)) {
            MsgBox, 16, JSON Error, Unterminated string
            ExitApp
        }
        ch := SubStr(__json_str, __json_pos, 1)
        if (ch = """") {
            __json_pos++
            break
        } else if (ch = "\") {
            __json_pos++
            esc := SubStr(__json_str, __json_pos, 1)
            __json_pos++
            if (esc = "n")
                result .= "`n"
            else if (esc = "r")
                result .= "`r"
            else if (esc = "t")
                result .= "`t"
            else if (esc = "b")
                result .= Chr(8)
            else if (esc = "f")
                result .= Chr(12)
            else if (esc = "\")
                result .= "\"
            else if (esc = "/")
                result .= "/"
            else if (esc = """")
                result .= """"
            else {
                MsgBox, 16, JSON Error, Invalid escape character \%esc%
                ExitApp
            }
        } else {
            result .= ch
            __json_pos++
        }
    }
    return result
}

JSON_ParseLiteral() {
    global __json_str, __json_pos
    if (SubStr(__json_str, __json_pos, 4) = "true") {
        __json_pos += 4
        return true
    } else if (SubStr(__json_str, __json_pos, 5) = "false") {
        __json_pos += 5
        return false
    } else if (SubStr(__json_str, __json_pos, 4) = "null") {
        __json_pos += 4
        return ""
    } else {
        MsgBox, 16, JSON Error, Invalid literal at position %__json_pos%
        ExitApp
    }
}

JSON_ParseNumber() {
    global __json_str, __json_pos
    number := ""
    dotSeen := false
    Loop {
        if (__json_pos > StrLen(__json_str))
            break
        ch := SubStr(__json_str, __json_pos, 1)
        if (ch = "." && !dotSeen) {
            dotSeen := true
            number .= ch
        } else if (ch ~= "[0-9]") {
            number .= ch
        } else {
            break
        }
        __json_pos++
    }
    return number + 0  ; Convert to number
}

JSON_Stringify(obj) {
    if IsObject(obj) {
        isArray := true
        for k in obj {
            if (k != A_Index) {
                isArray := false
                break
            }
        }

        json := isArray ? "[" : "{"
        for k, v in obj {
            if !isArray
                json .= """" k """:"
            json .= JSON_Stringify(v) . ","
        }
        return SubStr(json, 1, -1) . (isArray ? "]" : "}")
    } else if (obj = true) {
        return "true"
    } else if (obj = false) {
        return "false"
    } else if (obj = "") {
        return "null"
    } else if (RegExMatch(obj, "^\-?\d+(\.\d+)?$")) {
        return obj
    } else {
        return """" . StrReplace(StrReplace(obj, "\", "\\"), """", "\""") """"
    }
}
