#SingleInstance Force
#Include JSON.ahk

; ===================== CONFIG =====================
; Set provider to "claude" or "openai"
; "openai" works with any OpenAI-compatible API:
;   Together.xyz, OpenAI, Groq, Mistral, etc.
provider := "claude"

; Your API key
apiKey := "API_KEY_HERE"

; Model to use
; Claude examples:   claude-sonnet-4-20250514, claude-haiku-4-5-20251001
; Together examples: meta-llama/Llama-3.3-70B-Instruct-Turbo-Free
; OpenAI examples:   gpt-4o, gpt-4o-mini
; Groq examples:     llama3-70b-8192
model := "claude-sonnet-4-20250514"

; API base URL (only used when provider = "openai")
; Together.xyz: https://api.together.xyz/v1/chat/completions
; OpenAI:       https://api.openai.com/v1/chat/completions
; Groq:         https://api.groq.com/openai/v1/chat/completions
; Mistral:      https://api.mistral.ai/v1/chat/completions
apiUrl := "https://api.together.xyz/v1/chat/completions"

; Your prompt
prompt_prefix := "Read the following text and give a clear, concise summary in plain language. Focus on the main idea and skip unnecessary details. Use basic text, no formatting such as bold or italics:`n"
; ==================================================

curlPath := "C:\Windows\System32\curl.exe"
debugMode := false
global LoadingDots := 0
global Cancelled := false
global SummaryEdit := ""

^!s::
{
    ClipSaved := ClipboardAll
    Clipboard := ""
    SendInput, ^c
    Sleep, 500
    ClipWait, 3
    if (Clipboard = "") {
        MsgBox, 48, Error, No text selected or clipboard is empty.
        Clipboard := ClipSaved
        return
    }
    inputText := Clipboard
    Clipboard := ClipSaved
    if (debugMode)
        MsgBox, 64, Debug 1, Clipboard captured:`n%inputText%

    prompt := prompt_prefix . inputText
    requestObj := {}
    requestObj.model := model
    requestObj.max_tokens := 0 + 1024
    requestObj.stream := false
    requestObj.messages := [{ "role": "user", "content": prompt }]
    jsonPayload := JSON_Stringify(requestObj)

    if (debugMode)
        MsgBox, 64, Debug 2, JSON built:`n%jsonPayload%

    tempRequestFile := A_ScriptDir "\request.json"
    FileDelete, %tempRequestFile%
    FileAppend, %jsonPayload%, %tempRequestFile%, UTF-8-RAW

    if (debugMode)
        MsgBox, 64, Debug 3, Request file written. Sending API call now...

    tempResponseFile := A_ScriptDir "\response.json"
    FileDelete, %tempResponseFile%

    cmd := curlPath . " -s -X POST "

    if (provider = "claude") {
        cmd .= "https://api.anthropic.com/v1/messages"
        cmd .= " -H ""x-api-key: " apiKey """"
        cmd .= " -H ""anthropic-version: 2023-06-01"""
    } else {
        cmd .= apiUrl
        cmd .= " -H ""Authorization: Bearer " apiKey """"
    }

    cmd .= " -H ""Content-Type: application/json"""
    cmd .= " --data @" . """" . tempRequestFile . """"
    cmd .= " > """ . tempResponseFile . """"

    ; Show loading popup
    Cancelled := false
    Gui, Loading:Destroy
    Gui, Loading:New, +AlwaysOnTop +ToolWindow
    Gui, Loading:Color, 1E1E1E
    Gui, Loading:Font, s11 cE0E0E0 norm, Nunito
    Gui, Loading:Add, Text, x20 y15 w220 vLoadingText, Summarizing.
    Gui, Loading:Font, s9 cFFFFFF bold, Nunito
    Gui, Loading:Add, Button, x80 y45 w100 h28 gCancelSummary, Cancel
    Gui, Loading:Show, w260 h85, Loading
    SetTimer, AnimateLoading, 400

    Run, %ComSpec% /c %cmd%, , Hide, curlPID
    Loop {
        Process, Exist, %curlPID%
        if (!ErrorLevel || Cancelled)
            break
        Sleep, 100
    }
    SetTimer, AnimateLoading, Off
    Gui, Loading:Destroy
    if (Cancelled)
        return

    if (debugMode)
        MsgBox, 64, Debug 4, Curl finished. Checking for response file...

    if !FileExist(tempResponseFile) {
        MsgBox, 48, Error, No response file found. Curl likely failed.
        return
    }
    FileRead, responseJson, %tempResponseFile%

    if (debugMode)
        MsgBox, 64, Debug 5, Raw API response:`n%responseJson%

    FileDelete, %tempRequestFile%
    FileDelete, %tempResponseFile%

    responseObj := JSON_Parse(responseJson)
    summary := ""
    try {
        if (provider = "claude")
            summary := responseObj.content[1].text
        else
            summary := responseObj.choices[1].message.content
        summary := RegExReplace(summary, "\*\*|__|\*|_|~~|##|# ", "")
    } catch e {
        MsgBox, 48, Error, Failed to parse summary.`n%responseJson%
        return
    }
    ShowSummaryGui(summary)
}
return

AnimateLoading:
    global LoadingDots
    LoadingDots := Mod(LoadingDots, 3) + 1
    dots := SubStr("...", 1, LoadingDots)
    GuiControl, Loading:, LoadingText, Summarizing%dots%
return

CancelSummary:
    global Cancelled
    Cancelled := true
    SetTimer, AnimateLoading, Off
    Gui, Loading:Destroy
return

ShowSummaryGui(summary) {
    global summaryText, SummaryEdit
    summaryText := summary

    Gui, Summary:Destroy
    Gui, Summary:New, +AlwaysOnTop +ToolWindow +Resize, Summary
    Gui, Summary:Color, 1E1E1E

    Gui, Summary:Font, s16 cFFFFFF bold, Nunito
    Gui, Summary:Add, Text, x16 y18 w650 h40, Summary

    Gui, Summary:Font, s9 cAAAAAA norm, Nunito
    Gui, Summary:Add, Text, x26 y62 w618 0x10

    Gui, Summary:Font, s12 cE0E0E0 norm, Nunito
    Gui, Summary:Add, Edit, x26 y72 w570 h300 ReadOnly -E0x200 Background2D2D2D +VScroll vSummaryEdit, %summary%

    Gui, Summary:Font, s9 cFFFFFF bold, Nunito
    Gui, Summary:Add, Button, x16 y388 w300 h36 gCopySummary, Copy to Clipboard
    Gui, Summary:Add, Button, x334 y388 w300 h36 gCloseSummary, Close

    Gui, Summary:Show, w820 h600, Summary
}

SummaryGuiSize:
    EditH := A_GuiHeight - 152
    EditW := A_GuiWidth - 32
    BtnY := A_GuiHeight - 52
    BtnW := (A_GuiWidth - 48) // 2
    Btn2X := BtnW + 32
    GuiControl, Summary:Move, SummaryEdit, w%EditW% h%EditH%
    GuiControl, Summary:Move, Copy to Clipboard, y%BtnY% w%BtnW%
    GuiControl, Summary:Move, Close, x%Btn2X% y%BtnY% w%BtnW%
return

CopySummary:
    global summaryText
    Clipboard := summaryText
    MsgBox, 64, Copied, Summary copied to clipboard!
return

CloseSummary:
SummaryGuiClose:
    Gui, Summary:Destroy
return
